import 'package:flutter/material.dart';

class Communication_Screen extends StatelessWidget {
  const Communication_Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
     return Scaffold(body: Center(child: Text('Communication_Screen'),),);
  }
}