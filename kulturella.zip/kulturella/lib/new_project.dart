import 'package:flutter/material.dart';

class New_Project_Screen extends StatelessWidget {
  const New_Project_Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
     return Scaffold(body: Center(child: Text('New_Project_Screen'),),);
  }
}